/*
 * @brief Blinky example using timers and sysTick
 *
 * @note
 * Copyright(C) NXP Semiconductors, 2012
 * All rights reserved.
 *
 * @par
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * LPC products.  This software is supplied "AS IS" without any warranties of
 * any kind, and NXP Semiconductors and its licensor disclaim any and
 * all warranties, express or implied, including all implied warranties of
 * merchantability, fitness for a particular purpose and non-infringement of
 * intellectual property rights.  NXP Semiconductors assumes no responsibility
 * or liability for the use of the software, conveys no license or rights under any
 * patent, copyright, mask work right, or any other intellectual property rights in
 * or to any products. NXP Semiconductors reserves the right to make changes
 * in the software without notification. NXP Semiconductors also makes no
 * representation or warranty that such application will be suitable for the
 * specified use without further testing or modification.
 *
 * @par
 * Permission to use, copy, modify, and distribute this software and its
 * documentation is hereby granted, under NXP Semiconductors' and its
 * licensor's relevant copyrights in the software, without fee, provided that it
 * is used in conjunction with NXP Semiconductors microcontrollers.  This
 * copyright, permission, and disclaimer notice must appear in all copies of
 * this code.
 */

#include "board.h"
#include <stdio.h>

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

#define TICKRATE_HZ1 (10) /* 10 ticks per second */
#define TICKRATE_HZ2 (11) /* 11 ticks per second */
#define PWM_FREQ_MAX	5000 /* set PWM max frequency to 5 kHz*/
#define PWM_INIT_FREQ	2500 /* set PWM initial frequency to 2,5 kHz*/
/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/
uint32_t timerFreq;

volatile static uint32_t pwm_lut[] = {9598,9598,9598,9598,9598,9598,9597,9597,9597,9597,9596,9596,9595,9595,9595,9594,9593,9593,9592,9591,9591,9590,9589,9588,9587,9585,9584,9583,9581,9579,9577,9575,9573,9570,9568,9565,9561,9558,9554,9550,9545,9540,9534,9528,9521,9514,9506,9497,9488,9477,9466,9453,9440,9425,9409,9391,9371,9350,9327,9301,9273,9243,9210,9174,9134,9091,9043,8991,8935,8873,8805,8731,8650,8562,8465,8360,8244,8118,7980,7829,7665,7485,7288,7073,6837,6580,6299,5992,5657,5290,4889,4450,3971,3447,2875,2249,1565,817,0};

uint32_t pwm_cnt = 0, pwm_dir = 0;
/*****************************************************************************
 * Private functions
 ****************************************************************************/
void updateChannel(uint8_t red, uint8_t green, uint8_t blue);
/*****************************************************************************
 * Public functions
 ****************************************************************************/

/**
 * @brief	Handle interrupt from SysTick timer
 * @return	Nothing
 */
void SysTick_Handler(void)
{
	static int itrcnt = 0;

	if(++itrcnt == 5) {
		updateChannel(pwm_cnt,pwm_cnt,pwm_cnt);

		(pwm_dir==0) ? pwm_cnt++ : pwm_cnt--;

		if( pwm_cnt == 99){
			pwm_dir = 1;
		}
		if(pwm_cnt == 1){
			pwm_dir = 0;
		}
		itrcnt = 0;
	}
}

/**
 * @brief Update the PWM duty cycle of all channels using a logarithmic scale
 *
 * @param [in] value - a Value between 0 and 100 where 0 is off and 100 is max brightness
 */
void updateChannel(volatile uint8_t red, uint8_t green, uint8_t blue){
	Chip_TIMER_SetMatch(LPC_TIMER32_0, 0, ((timerFreq/PWM_FREQ_MAX) - pwm_lut[blue]));
	Chip_TIMER_SetMatch(LPC_TIMER32_0, 1, ((timerFreq/PWM_FREQ_MAX) - pwm_lut[green]));
	Chip_TIMER_SetMatch(LPC_TIMER16_1, 0, ((timerFreq/PWM_FREQ_MAX) - pwm_lut[red]));
}

/**
 * @brief	main routine for blinky example
 * @return	Function should not exit.
 */
int main(void)
{
	SystemCoreClockUpdate();
	Board_Init();

	timerFreq = Chip_Clock_GetSystemClockRate();

	/* Enable and setup SysTick Timer at a periodic rate */
	SysTick_Config(SystemCoreClock/1000);

	Chip_GPIO_SetDir(LPC_GPIO, 1, 0x2C0, 1); // set Pin 1.[6,7,9] to output
	/* configure the GPIO alternate function to Timer PWM output */
	Chip_IOCON_PinMuxSet(LPC_IOCON,IOCON_PIO1_6, IOCON_FUNC2 | IOCON_MODE_PULLUP); // red
	Chip_IOCON_PinMuxSet(LPC_IOCON,IOCON_PIO1_7, IOCON_FUNC2 | IOCON_MODE_PULLUP); // green
	Chip_IOCON_PinMuxSet(LPC_IOCON,IOCON_PIO1_9, IOCON_FUNC1 | IOCON_MODE_PULLUP); // blue

	/* Init Timers */
	Chip_TIMER_Init(LPC_TIMER32_0);
	Chip_TIMER_Init(LPC_TIMER16_1);

	Chip_TIMER_Reset(LPC_TIMER32_0);
	Chip_TIMER_Reset(LPC_TIMER16_1);
	//Chip_TIMER_MatchEnableInt(LPC_TIMER16_1, 1);
	//Chip_TIMER_SetMatch(LPC_TIMER16_1, 1, (timerFreq / TICKRATE_HZ2));

	Chip_TIMER_SetMatch(LPC_TIMER32_0, 3, timerFreq/PWM_FREQ_MAX); // set max match to full scale
	Chip_TIMER_SetMatch(LPC_TIMER32_0, 1, timerFreq/PWM_INIT_FREQ);
	Chip_TIMER_SetMatch(LPC_TIMER32_0, 0, timerFreq/PWM_INIT_FREQ);

	Chip_TIMER_SetMatch(LPC_TIMER16_1,3, timerFreq/PWM_FREQ_MAX); // set max match to full scale
	Chip_TIMER_SetMatch(LPC_TIMER16_1, 0, timerFreq/PWM_INIT_FREQ);
	LPC_TIMER16_1->PWMC |= (1<<0); // enable PWM out on CT16B1_MAT0
	LPC_TIMER32_0->PWMC |= (3<<0); // enable PWM out on CT32B0_MAT0/1

	Chip_TIMER_ResetOnMatchEnable(LPC_TIMER32_0, 3);
	Chip_TIMER_ResetOnMatchEnable(LPC_TIMER16_1, 3);

	Chip_TIMER_Enable(LPC_TIMER16_1);
	Chip_TIMER_Enable(LPC_TIMER32_0);

	/* LEDs toggle in interrupt handlers */
	while (1) {
		__WFI();
	}


	return 0;
}
